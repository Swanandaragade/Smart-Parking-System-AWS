document.addEventListener('DOMContentLoaded', () => {
    // API Endpoints: (keep these as provided by you)
    const apiUrl = 'https://8qfkfaypqj.execute-api.ap-south-1.amazonaws.com/default/AvailabilityLambda';
    const subscribeApiUrl = 'https://8qfkfaypqj.execute-api.ap-south-1.amazonaws.com/default/Notification';

    const form = document.getElementById('parking-form');
    const areaSelect = document.getElementById('area-select');
    const floorSelect = document.getElementById('floor-select');
    const resultContainer = document.getElementById('result-container');
    const notificationSection = document.getElementById('notification-section');
    const notifyButton = document.getElementById('notify-button');
    const notificationModal = document.getElementById('notification-modal');
    const modalAreaSpan = document.getElementById('modal-area');
    const modalFloorSpan = document.getElementById('modal-floor');
    const notificationEmailInput = document.getElementById('notification-email');
    const subscribeConfirmButton = document.getElementById('subscribe-confirm-button');
    const closeModalButton = document.getElementById('close-modal-button');
    const notificationStatus = document.getElementById('notification-status');

    // Dynamically populate Area (1–4) and Floor (1–5)
    function populateDropdown(selectElement, count, label) {
        selectElement.innerHTML = '';
        for (let i = 1; i <= count; i++) {
            selectElement.innerHTML += `<option value="${i}">${label} ${i}</option>`;
        }
    }

    populateDropdown(areaSelect, 4, 'Area');
    populateDropdown(floorSelect, 5, 'Floor');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        resultContainer.innerHTML = '<div class="loader"></div>';
        notificationSection.style.display = 'none';

        const area = areaSelect.value;
        const floor = floorSelect.value;
        const fullApiUrl = `${apiUrl}?area=${area}&floor=${floor}`;

        try {
            const response = await fetch(fullApiUrl);
            if (!response.ok) {
                const errorBody = await response.json();
                throw new Error(errorBody.message || `HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            renderResult(result, area, floor);
        } catch (error) {
            console.error("Error fetching parking data:", error);
            renderResult({ status: 'ERROR', message: `Failed to connect or API error: ${error.message}` });
        }
    });

    function renderResult(data, area, floor) {
        resultContainer.innerHTML = '';
        let cardHtml = '';

        switch (data.status) {
            case 'AVAILABLE':
                let slotsGridHtml = data.slots.map(slot =>
                    `<div class="slot-item">${slot.parking_id}</div>`
                ).join('');
                cardHtml = `
                    <div class="result-card result-success">
                        <h2>Available Slots</h2>
                        <p>${data.message}</p>
                        <div class="slot-grid">${slotsGridHtml}</div>
                    </div>`;
                notificationSection.style.display = 'none';
                break;

            case 'FULL':
                let upcomingHtml = data.upcoming_slots.length > 0
                    ? data.upcoming_slots.map(slot => `<li>Slot <strong>${slot.parking_id}</strong> will be free in ~${slot.wait_minutes} min</li>`).join('')
                    : '<li>No upcoming slots found. Please check back later.</li>';
                cardHtml = `
                    <div class="result-card result-full">
                        <h2>Floor Full</h2>
                        <p>${data.message}</p>
                        <ul class="upcoming-list">${upcomingHtml}</ul>
                    </div>`;
                notificationSection.style.display = 'block';
                modalAreaSpan.textContent = area;
                modalFloorSpan.textContent = floor;
                break;

            case 'ERROR':
            default:
                cardHtml = `
                    <div class="result-card result-error">
                        <h2>An Error Occurred</h2>
                        <p>${data.message || 'Unknown error.'}</p>
                    </div>`;
                notificationSection.style.display = 'none';
                break;
        }
        resultContainer.innerHTML = cardHtml;
    }

    notifyButton.addEventListener('click', () => {
        notificationModal.style.display = 'block';
        notificationStatus.textContent = '';
        notificationEmailInput.value = '';
    });
    closeModalButton.addEventListener('click', () => {
        notificationModal.style.display = 'none';
    });
    window.addEventListener('click', (event) => {
        if (event.target == notificationModal) {
            notificationModal.style.display = 'none';
        }
    });
    subscribeConfirmButton.addEventListener('click', async () => {
        const email = notificationEmailInput.value;
        const area = areaSelect.value;
        const floor = floorSelect.value;
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            notificationStatus.textContent = 'Please enter a valid email address.';
            notificationStatus.style.color = 'red';
            return;
        }
        if (!area || !floor) {
            notificationStatus.textContent = 'Error: Area or floor not selected.';
            notificationStatus.style.color = 'red';
            return;
        }
        notificationStatus.textContent = 'Sending subscription request...';
        notificationStatus.style.color = 'blue';
        subscribeConfirmButton.disabled = true;
        try {
            const response = await fetch(subscribeApiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    area_number: parseInt(area),
                    floor_number: parseInt(floor)
                }),
            });
            const result = await response.json();
            if (response.ok) {
                notificationStatus.textContent = result.message || 'Subscription request sent successfully!';
                notificationStatus.style.color = 'green';
            } else {
                notificationStatus.textContent = result.message || `Subscription failed. Status: ${response.status}`;
                notificationStatus.style.color = 'red';
            }
        } catch (error) {
            console.error('Subscription API error:', error);
            notificationStatus.textContent = `Failed to connect to subscription service: ${error.message}`;
            notificationStatus.style.color = 'red';
        } finally {
            subscribeConfirmButton.disabled = false;
        }
    });
});
