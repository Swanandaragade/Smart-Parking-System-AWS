import json
import boto3
from datetime import datetime, timedelta, timezone
import uuid
from boto3.dynamodb.conditions import Attr
import os 


dynamodb = boto3.resource('dynamodb')
parking_table = dynamodb.Table('ParkingSlotDatabase')
logs_table = dynamodb.Table('ParkingHistory')

def lambda_handler(event, context):
    # Parse input
    vehicle_id = event.get('vehicle_id')
    event_type = event.get('event')
    expected_time = event.get('expected')
    area = event.get('area')
    floor = event.get('floor')
    email = event.get('email')
    
    try:
        if event_type not in ['entry', 'exit']:
            # ADDED: Log invalid event type to CloudWatch
            print(json.dumps({'log_level': 'ERROR', 'message': 'Invalid event type received', 'input': event}))
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid event type. Use "entry" or "exit"'})
            }
            
        if event_type == 'entry':
            if not (vehicle_id and expected_time is not None and area and email):
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'vehicle_id, expected_time (in minutes), area, and email are required for entry'})
                }
            try:
                expected_minutes = int(expected_time)
            except ValueError:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'expected_time must be a number (minutes)'})
                }
            return handle_entry(vehicle_id, expected_minutes, area, floor, email)
        else:
            if not vehicle_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'vehicle_id is required for exit'})
                }
            return handle_exit(vehicle_id)
            
    except Exception as e:
        # ADDED: Log unexpected exceptions to CloudWatch
        print(json.dumps({'log_level': 'CRITICAL', 'message': 'An unexpected error occurred', 'error': str(e)}))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


def handle_entry(vehicle_id, expected_minutes, area, floor, email):

    ist_offset = timedelta(hours=5, minutes=30)
    entry_timestamp = (datetime.now(timezone.utc) + ist_offset).isoformat()
    expected_exit_time = (datetime.fromisoformat(entry_timestamp) + timedelta(minutes=expected_minutes)).isoformat()
    
    filter_expression = 'area_number = :area AND #s = :status'
    expression_values = {':area': int(area), ':status': 'empty'}
    expression_names = {'#s': 'status'}
    
    if floor:
        filter_expression += ' AND floor_number = :floor'
        expression_values[':floor'] = int(floor)
    
    response = parking_table.scan(
        FilterExpression=filter_expression,
        ExpressionAttributeValues=expression_values,
        ExpressionAttributeNames=expression_names
    )
    
    if not response['Items']:
        # ADDED: Log failed attempt to find a slot
        print(json.dumps({'log_level': 'WARN', 'message': 'No available slots found', 'area': area, 'floor': floor}))
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'No available parking slots in area {area}' + (f' floor {floor}' if floor else '')})
        }
    
    slots = sorted(response['Items'], key=lambda x: (int(x['floor_number']), int(x['slot_number'])))
    selected_slot = slots[0]
    parking_id = selected_slot['parking_id']

    # CHANGED: Added entry_timestamp to the update expression
    parking_table.update_item(
        Key={'parking_id': parking_id},
        UpdateExpression='SET #status = :occupied, vehicle_id = :vehicle_id, expected_time = :expected_time, entry_timestamp = :entry_ts, email = :email',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={
            ':occupied': 'occupied',
            ':vehicle_id': vehicle_id,
            ':expected_time': expected_exit_time,
            ':entry_ts': entry_timestamp,
            ':email': email
        }
    )

    # ADDED: Log successful entry to CloudWatch
    print(json.dumps({
        'event_type': 'VEHICLE_ENTRY', 'status': 'SUCCESS', 'vehicle_id': vehicle_id, 
        'parking_id': parking_id, 'timestamp': entry_timestamp
    }))
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': f'Vehicle {vehicle_id} assigned to slot {parking_id}', 'parking_id': parking_id,
            'entry_timestamp': entry_timestamp, 'expected_exit_time': expected_exit_time
        })
    }

def handle_exit(vehicle_id):
    response = parking_table.query(
        IndexName='vehicle_id-index',
        KeyConditionExpression='vehicle_id = :vehicle_id',
        FilterExpression='#status = :occupied',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={':vehicle_id': vehicle_id, ':occupied': 'occupied'}
    )
    
    if not response['Items']:
        # ADDED: Log failed exit attempt
        print(json.dumps({'log_level': 'WARN', 'message': 'Exit attempt for a vehicle not found', 'vehicle_id': vehicle_id}))
        return {
            'statusCode': 404,
            'body': json.dumps({'error': f'No slot found for vehicle {vehicle_id}'})
        }

    slot_info = response['Items'][0]
    parking_id = slot_info['parking_id']
    
    ist_offset = timedelta(hours=5, minutes=30)
    exit_timestamp = (datetime.now(timezone.utc) + ist_offset).isoformat()
    
    # ADDED: Logic to calculate parking duration
    duration_minutes = None
    entry_timestamp_str = slot_info.get('entry_timestamp')
    if entry_timestamp_str:
        duration = datetime.fromisoformat(exit_timestamp) - datetime.fromisoformat(entry_timestamp_str)
        duration_minutes = int(duration.total_seconds() / 60)

    # CHANGED: Remove entry_timestamp on exit to clean up the item
    parking_table.update_item(
        Key={'parking_id': parking_id},
        UpdateExpression='SET #status = :empty REMOVE vehicle_id, expected_time, entry_timestamp, email',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={':empty': 'empty'}
    )
    

    log_item = {
    'location_id': str(slot_info.get('area_number')),  # The Partition Key for your logs table
    'exit_timestamp': exit_timestamp,                 # The Sort Key for your logs table
    'session_id': str(uuid.uuid4()),                  # A unique identifier for the parking session
    'vehicle_id': vehicle_id,
    'parking_id': parking_id,
    'entry_timestamp': slot_info.get('entry_timestamp'),
    'duration_minutes': duration_minutes,
    'floor_number': str(slot_info.get('floor_number')) # Extra useful data for filtering reports
    }

    # This removes any keys that might have a None value to prevent errors with DynamoDB
    final_log_item = {k: v for k, v in log_item.items() if v is not None}

    logs_table.put_item(Item=final_log_item)
    
    # ADDED: Log successful exit to CloudWatch, including the duration
    print(json.dumps({
        'event_type': 'VEHICLE_EXIT', 'status': 'SUCCESS', 'vehicle_id': vehicle_id,
        'parking_id': parking_id, 'timestamp': exit_timestamp, 'duration_minutes': duration_minutes
    }))
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': f'Vehicle {vehicle_id} exited from slot {parking_id}', 'parking_id': parking_id,
            'exit_timestamp': exit_timestamp
        })
    }